These programs perform clustering on the data in datasets 1, 2, and 3. Run them with the following commands.

python ./KMeans.py
python ./DBSCAN.py
python ./GMM.py

They will output the results of the clustering into CSV files with the clustering method and dataset in the name.
If you run all of these programs you should get 9 CSV files.